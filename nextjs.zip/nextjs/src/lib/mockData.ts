import { Flight, Passenger, Seat, BookingSummaryType } from "../types/booking";

export const mockFlights: Flight[] = [
  {
    id: "AI247",
    flightNumber: "AI 247",
    aircraft: "Boeing 787-9 Dreamliner",
    departureCity: "Mumbai",
    arrivalCity: "Dubai",
    departureCode: "BOM",
    arrivalCode: "DXB",
    departureTime: "09:30 PM",
    arrivalTime: "11:50 PM",
    date: "Tue, 20 May",
    duration: "02h 20m",
    baseFare: 220,
    bestValue: true,
  },
];

export const mockPassenger: Passenger = {
  name: "John Smith",
  type: "Adult",
  count: 1,
};

const ECONOMY_COLS = ["A", "B", "C", "D", "E", "F"];
const BUSINESS_COLS = ["A", "C", "D", "F"];

export const mockSeats: Seat[] = [];

// Business 1-7
for (let row = 1; row <= 7; row++) {
  BUSINESS_COLS.forEach((col) => {
    mockSeats.push({
      id: `${row}${col}`,
      row,
      column: col,
      cabinClass: "Business",
      status: Math.random() > 0.8 ? "booked" : "available",
      isExtraLegroom: false,
      price: 150,
      features: ["Lie-flat bed", "Premium meals", "Lounge access"],
    });
  });
}

// Premium Economy 10-14
for (let row = 10; row <= 14; row++) {
  ECONOMY_COLS.forEach((col) => {
    mockSeats.push({
      id: `${row}${col}`,
      row,
      column: col,
      cabinClass: "Premium Economy",
      status: Math.random() > 0.7 ? "booked" : "available",
      isExtraLegroom: false,
      price: 50,
      features: ["Extra recline", "Priority boarding", "Enhanced meals"],
    });
  });
}

// Extra Legroom 15-17
for (let row = 15; row <= 17; row++) {
  ECONOMY_COLS.forEach((col) => {
    mockSeats.push({
      id: `${row}${col}`,
      row,
      column: col,
      cabinClass: "Economy",
      status: "available",
      isExtraLegroom: true,
      price: 24,
      features: ["Extra Legroom", "Near Exit", "Faster boarding"],
    });
  });
}

// Economy 18-30
for (let row = 18; row <= 30; row++) {
  ECONOMY_COLS.forEach((col) => {
    mockSeats.push({
      id: `${row}${col}`,
      row,
      column: col,
      cabinClass: "Economy",
      status:
        row === 18 && col === "A"
          ? "available"
          : Math.random() > 0.6
          ? "booked"
          : "available",
      isExtraLegroom: false,
      price: 0,
      features: ["Standard seat"],
    });
  });
}

export const baseBookingSummary: BookingSummaryType = {
  flight: mockFlights[0],
  passenger: mockPassenger,
  selectedSeats: [],
  selectedCabinClass: "Economy",
  taxesAndFees: 10,
};
