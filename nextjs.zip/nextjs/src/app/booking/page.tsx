"use client";

import React, { useState, useCallback, useMemo } from "react";
import { StepStatus, Flight, Seat, CabinClass, BookingSummaryType } from "@/types/booking";
import { mockFlights, mockSeats, mockPassenger, baseBookingSummary } from "@/lib/mockData";
import { BookingLayout } from "@/components/layout/BookingLayout";
import { FlightPlanStep } from "@/components/booking/FlightPlanStep";
import { SelectSeatStep } from "@/components/booking/SelectSeatStep";
import { PaymentStep } from "@/components/booking/PaymentStep";
import { ConfirmationStep } from "@/components/booking/ConfirmationStep";

const stepConfig: Record<StepStatus, { title: string; subtitle: string }> = {
  plan: {
    title: "Plan your trip",
    subtitle: "Review your flight and continue to seat selection",
  },
  "select-seat": {
    title: "Select your seat",
    subtitle: "Choose your exact seat and review nearby availability.",
  },
  payment: {
    title: "Payment",
    subtitle: "Review your booking and complete payment.",
  },
  confirmation: {
    title: "Booking Confirmed",
    subtitle: "Your seat has been reserved successfully.",
  },
};

const stepOrder: StepStatus[] = ["plan", "select-seat", "payment", "confirmation"];

export default function BookingPage() {
  const [currentStep, setCurrentStep] = useState<StepStatus>("plan");
  const [selectedFlight, setSelectedFlight] = useState<Flight>(mockFlights[0]);
  const [selectedSeats, setSelectedSeats] = useState<Seat[]>([]);
  const [selectedCabinClass, setSelectedCabinClass] = useState<CabinClass>("Economy");
  const [seats] = useState<Seat[]>(mockSeats);

  const handleSelectFlight = useCallback((flight: Flight) => {
    setSelectedFlight(flight);
  }, []);

  const handleSelectSeat = useCallback((seat: Seat) => {
    setSelectedSeats((prev) => {
      const isSelected = prev.some((s) => s.id === seat.id);
      if (isSelected) {
        return prev.filter((s) => s.id !== seat.id);
      } else {
        return [...prev, seat];
      }
    });
  }, []);

  const handleSelectCabinClass = useCallback((cabinClass: CabinClass) => {
    setSelectedCabinClass(cabinClass);
    // Clear selected seats when changing class — seats from another class shouldn't persist
    setSelectedSeats([]);
  }, []);

  const summary: BookingSummaryType = useMemo(() => ({
    ...baseBookingSummary,
    flight: selectedFlight,
    selectedSeats,
    selectedCabinClass,
  }), [selectedFlight, selectedSeats, selectedCabinClass]);

  const handleContinue = useCallback(() => {
    const currentIdx = stepOrder.indexOf(currentStep);
    if (currentIdx < stepOrder.length - 1) {
      setCurrentStep(stepOrder[currentIdx + 1]);
    }
  }, [currentStep]);

  const handleBack = useCallback(() => {
    const currentIdx = stepOrder.indexOf(currentStep);
    if (currentIdx > 0) {
      setCurrentStep(stepOrder[currentIdx - 1]);
    }
  }, [currentStep]);

  const handlePaymentComplete = useCallback(() => {
    setCurrentStep("confirmation");
  }, []);

  const handleEditStep = useCallback((step: StepStatus) => {
    setCurrentStep(step);
  }, []);

  const isContinueDisabled = currentStep === "select-seat" && selectedSeats.length === 0;

  const { title, subtitle } = stepConfig[currentStep];

  return (
    <BookingLayout
      currentStep={currentStep}
      summary={summary}
      title={title}
      subtitle={subtitle}
      onContinue={handleContinue}
      onBack={handleBack}
      isContinueDisabled={isContinueDisabled}
      onEditStep={handleEditStep}
    >
      {currentStep === "plan" && (
        <FlightPlanStep
          flights={mockFlights}
          selectedFlight={selectedFlight}
          onSelectFlight={handleSelectFlight}
          selectedCabinClass={selectedCabinClass}
          onSelectCabinClass={handleSelectCabinClass}
          summary={summary}
        />
      )}
      {currentStep === "select-seat" && (
        <SelectSeatStep
          seats={seats}
          selectedSeats={selectedSeats}
          selectedCabinClass={selectedCabinClass}
          onSelectSeat={handleSelectSeat}
          onContinue={handleContinue}
        />
      )}
      {currentStep === "payment" && (
        <PaymentStep summary={summary} onComplete={handlePaymentComplete} />
      )}
      {currentStep === "confirmation" && (
        <ConfirmationStep summary={summary} />
      )}
    </BookingLayout>
  );
}
