"use client";

import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { BookingSummaryType, CABIN_CLASS_PRICE_ADDON } from "../../types/booking";
import {
  CheckCircle2,
  Plane,
  Download,
  Share2,
  Calendar,
  Clock,
  Armchair,
  Copy,
  CheckCheck,
} from "lucide-react";

interface ConfirmationStepProps {
  summary: BookingSummaryType;
}

export const ConfirmationStep = ({ summary }: ConfirmationStepProps) => {
  const [copied, setCopied] = useState(false);
  const [confetti, setConfetti] = useState(true);

  // Generate a fake booking reference
  const bookingRef = "AV-" + Math.random().toString(36).substring(2, 8).toUpperCase();

  useEffect(() => {
    const timer = setTimeout(() => setConfetti(false), 3000);
    return () => clearTimeout(timer);
  }, []);

  const handleCopy = () => {
    navigator.clipboard.writeText(bookingRef);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const numSeats = summary.selectedSeats.length || 1;
  const cabinAddon = CABIN_CLASS_PRICE_ADDON[summary.selectedCabinClass] || 0;
  const total =
    ((summary.flight?.baseFare || 0) + cabinAddon) * numSeats +
    summary.selectedSeats.reduce((sum, seat) => sum + seat.price, 0) +
    summary.taxesAndFees -
    (summary.discount || 0);

  return (
    <div className="flex justify-center items-start pt-4 pb-20 px-8">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="w-full max-w-[560px]"
      >
        {/* Success Header */}
        <div className="text-center mb-8">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 200, damping: 15, delay: 0.2 }}
            className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-5"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 300, damping: 20, delay: 0.5 }}
            >
              <CheckCircle2 className="w-10 h-10 text-green-500" />
            </motion.div>
          </motion.div>
          <motion.h1
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="text-2xl font-bold text-gray-900 mb-2"
          >
            Booking Confirmed!
          </motion.h1>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
            className="text-sm text-gray-500"
          >
            Your seat has been reserved. A confirmation email has been sent.
          </motion.p>
        </div>

        {/* Booking Reference Card */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9 }}
          className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden mb-4"
        >
          {/* Reference */}
          <div className="bg-gradient-to-r from-blue-600 to-indigo-600 px-6 py-4 text-white">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-[10px] uppercase tracking-widest opacity-80 mb-1">
                  Booking Reference
                </div>
                <div className="text-2xl font-bold tracking-wider">{bookingRef}</div>
              </div>
              <button
                onClick={handleCopy}
                className="flex items-center gap-1.5 bg-white/20 hover:bg-white/30 rounded-lg px-3 py-2 text-xs font-medium transition-colors"
              >
                {copied ? (
                  <>
                    <CheckCheck className="w-3.5 h-3.5" /> Copied
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" /> Copy
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Flight Details */}
          <div className="p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <div className="text-3xl font-bold text-gray-900">
                  {summary.flight?.departureCode}
                </div>
                <div className="text-xs text-gray-500 mt-0.5">
                  {summary.flight?.departureCity}
                </div>
              </div>
              <div className="flex flex-col items-center flex-1 mx-6">
                <div className="flex items-center w-full">
                  <div className="w-2 h-2 rounded-full bg-blue-600" />
                  <div className="flex-1 h-[1.5px] bg-gray-200 mx-2 relative">
                    <Plane className="w-4 h-4 text-blue-600 absolute left-1/2 -translate-x-1/2 -top-[7px]" />
                  </div>
                  <div className="w-2 h-2 rounded-full bg-blue-600" />
                </div>
                <div className="text-[10px] text-gray-400 mt-1.5">Non-stop</div>
              </div>
              <div className="text-right">
                <div className="text-3xl font-bold text-gray-900">
                  {summary.flight?.arrivalCode}
                </div>
                <div className="text-xs text-gray-500 mt-0.5">
                  {summary.flight?.arrivalCity}
                </div>
              </div>
            </div>

            {/* Info Grid */}
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-gray-50 rounded-xl p-3.5">
                <div className="flex items-center gap-2 mb-1.5">
                  <Calendar className="w-3.5 h-3.5 text-gray-400" />
                  <span className="text-[10px] text-gray-400 uppercase tracking-wider">Date</span>
                </div>
                <div className="text-sm font-semibold text-gray-900">
                  {summary.flight?.date}
                </div>
              </div>
              <div className="bg-gray-50 rounded-xl p-3.5">
                <div className="flex items-center gap-2 mb-1.5">
                  <Clock className="w-3.5 h-3.5 text-gray-400" />
                  <span className="text-[10px] text-gray-400 uppercase tracking-wider">Time</span>
                </div>
                <div className="text-sm font-semibold text-gray-900">
                  {summary.flight?.departureTime}
                </div>
              </div>
              <div className="bg-gray-50 rounded-xl p-3.5">
                <div className="flex items-center gap-2 mb-1.5">
                  <Armchair className="w-3.5 h-3.5 text-gray-400" />
                  <span className="text-[10px] text-gray-400 uppercase tracking-wider">Seat</span>
                </div>
                <div className="text-sm font-semibold text-gray-900">
                  {summary.selectedSeats.length > 0 ? summary.selectedSeats.map(s => s.id).join(", ") : "—"}{" "}
                  <span className="text-gray-400 font-normal text-xs">
                    ({summary.selectedSeats[0]?.cabinClass || "Economy"})
                  </span>
                </div>
              </div>
              <div className="bg-gray-50 rounded-xl p-3.5">
                <div className="flex items-center gap-2 mb-1.5">
                  <Plane className="w-3.5 h-3.5 text-gray-400" />
                  <span className="text-[10px] text-gray-400 uppercase tracking-wider">Flight</span>
                </div>
                <div className="text-sm font-semibold text-gray-900">
                  {summary.flight?.flightNumber}
                </div>
              </div>
            </div>

            {/* Passenger & Total */}
            <div className="flex items-center justify-between pt-4 border-t border-gray-100">
              <div>
                <div className="text-[10px] text-gray-400 uppercase tracking-wider mb-0.5">
                  Passenger
                </div>
                <div className="text-sm font-semibold text-gray-900">
                  {summary.passenger.name}
                </div>
              </div>
              <div className="text-right">
                <div className="text-[10px] text-gray-400 uppercase tracking-wider mb-0.5">
                  Total Paid
                </div>
                <div className="text-lg font-bold text-blue-600">
                  USD {total.toFixed(2)}
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.1 }}
          className="flex gap-3"
        >
          <button className="flex-1 flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl py-3.5 text-sm font-semibold shadow-lg shadow-blue-200 transition-colors">
            <Download className="w-4 h-4" />
            Download E-Ticket
          </button>
          <button className="flex items-center justify-center gap-2 bg-white hover:bg-gray-50 border border-gray-200 text-gray-700 rounded-xl px-6 py-3.5 text-sm font-semibold transition-colors">
            <Share2 className="w-4 h-4" />
            Share
          </button>
        </motion.div>
      </motion.div>
    </div>
  );
};
