"use client";

import React, { useState, useCallback, memo } from "react";
import { Seat, CabinClass } from "../../types/booking";

/* ═══════════════════════════════════════════════════════════
   TOOLTIP — Shows seat price, class, and features on hover
   ═══════════════════════════════════════════════════════════ */
const SeatTooltip = ({ seat }: { seat: Seat }) => {
  const isBooked = seat.status === "booked";

  const classLabel =
    seat.cabinClass === "Business"
      ? "Business Class"
      : seat.cabinClass === "Premium Economy"
      ? "Premium Economy"
      : seat.isExtraLegroom
      ? "Extra Legroom"
      : "Economy";

  const dotColor =
    seat.cabinClass === "Business"
      ? "bg-purple-400"
      : seat.cabinClass === "Premium Economy"
      ? "bg-blue-400"
      : seat.isExtraLegroom
      ? "bg-emerald-400"
      : "bg-slate-400";

  return (
    <div className="seat-tooltip pointer-events-none w-max">
      <div className="bg-[#0A1931] text-white rounded-xl px-4 py-3 shadow-2xl shadow-black/40 min-w-[155px] backdrop-blur-sm">
        {/* Header: Seat ID + Price */}
        <div className="flex items-center justify-between gap-6 mb-1">
          <span className="text-[13px] font-extrabold tracking-wider">{seat.id}</span>
          {isBooked ? (
            <span className="text-[11px] font-semibold text-red-400">Occupied</span>
          ) : (
            <span className="text-[13px] font-extrabold text-emerald-400">
              ${seat.price > 0 ? seat.price.toFixed(2) : "Free"}
            </span>
          )}
        </div>
        {/* Class badge */}
        <div className="flex items-center gap-1.5 mb-0.5">
          <span className={`inline-block w-[6px] h-[6px] rounded-full ${dotColor}`} />
          <span className="text-[10px] text-slate-300 font-medium">{classLabel}</span>
        </div>
        {/* Features */}
        {!isBooked && seat.features.length > 0 && (
          <div className="mt-2 pt-1.5 border-t border-white/10 flex flex-wrap gap-1">
            {seat.features.slice(0, 2).map((f) => (
              <span
                key={f}
                className="text-[8px] px-1.5 py-[2px] bg-white/[0.08] rounded text-slate-400 font-medium"
              >
                {f}
              </span>
            ))}
          </div>
        )}
      </div>
      {/* Tooltip caret */}
      <div className="flex justify-center -mt-[1px]">
        <div className="w-0 h-0 border-l-[7px] border-r-[7px] border-t-[7px] border-l-transparent border-r-transparent border-t-[#0A1931]" />
      </div>
    </div>
  );
};

/* ═══════════════════════════════════════════════════════════
   SEAT ICON — SVG seat with headrest, body, and cushion
   ═══════════════════════════════════════════════════════════ */
interface SeatIconProps {
  seat: Seat;
  isSelected: boolean;
  isHovered: boolean;
}

const SEAT_W = 26;
const SEAT_H = 30;

const SeatIconComponent = ({ seat, isSelected, isHovered }: SeatIconProps) => {
  const isBooked = seat.status === "booked";

  let fill: string, stroke: string, innerFill: string, textColor: string;

  if (isSelected) {
    fill = "#005BFF";
    stroke = "#0047CC";
    innerFill = "rgba(255,255,255,0.18)";
    textColor = "#FFFFFF";
  } else if (isBooked) {
    if (seat.cabinClass === "Business") {
      fill = "#F5F3FF"; stroke = "#E9E5FF"; innerFill = "#FAF9FF";
    } else if (seat.cabinClass === "Premium Economy") {
      fill = "#EFF6FF"; stroke = "#DBEAFE"; innerFill = "#F8FBFF";
    } else {
      fill = "#F8FAFC"; stroke = "#E2E8F0"; innerFill = "#FAFBFC";
    }
    textColor = "#C8CDD5";
  } else if (seat.cabinClass === "Business") {
    fill = isHovered ? "#B794F4" : "#C4B5FD";
    stroke = isHovered ? "#9061F0" : "#A78BFA";
    innerFill = "rgba(255,255,255,0.22)";
    textColor = "#7C3AED";
  } else if (seat.cabinClass === "Premium Economy") {
    fill = isHovered ? "#4F9CF7" : "#60A5FA";
    stroke = isHovered ? "#2563EB" : "#3B82F6";
    innerFill = "rgba(255,255,255,0.22)";
    textColor = "#FFFFFF";
  } else if (seat.isExtraLegroom) {
    fill = isHovered ? "#D1FAE5" : "#ECFDF5";
    stroke = isHovered ? "#34D399" : "#6EE7B7";
    innerFill = "rgba(255,255,255,0.5)";
    textColor = "#059669";
  } else {
    fill = isHovered ? "#EEF2FF" : "#FFFFFF";
    stroke = isHovered ? "#818CF8" : "#CBD5E1";
    innerFill = "rgba(255,255,255,0.3)";
    textColor = "#64748B";
  }

  return (
    <svg width={SEAT_W} height={SEAT_H} viewBox={`0 0 ${SEAT_W} ${SEAT_H}`} fill="none" className="block">
      {/* Headrest */}
      <rect x={SEAT_W * 0.22} y={0.5} width={SEAT_W * 0.56} height={SEAT_H * 0.22} rx={2.5} ry={2.5} fill={fill} stroke={stroke} strokeWidth={1} />
      {/* Seat body */}
      <rect x={1} y={SEAT_H * 0.16} width={SEAT_W - 2} height={SEAT_H * 0.78} rx={3.5} ry={3.5} fill={fill} stroke={stroke} strokeWidth={1.2} />
      {/* Inner cushion */}
      <rect x={SEAT_W * 0.16} y={SEAT_H * 0.3} width={SEAT_W * 0.68} height={SEAT_H * 0.5} rx={2.5} ry={2.5} fill={innerFill} stroke={stroke} strokeWidth={0.4} opacity={0.5} />
      {/* Armrest left */}
      <rect x={0} y={SEAT_H * 0.35} width={2} height={SEAT_H * 0.35} rx={1} fill={stroke} opacity={0.3} />
      {/* Armrest right */}
      <rect x={SEAT_W - 2} y={SEAT_H * 0.35} width={2} height={SEAT_H * 0.35} rx={1} fill={stroke} opacity={0.3} />

      {/* Text overlays */}
      {isBooked && (
        <text x={SEAT_W / 2} y={SEAT_H * 0.58} textAnchor="middle" dominantBaseline="central" fill={textColor} fontSize={9} fontWeight={700}>✕</text>
      )}
      {isSelected && (
        <text x={SEAT_W / 2} y={SEAT_H * 0.58} textAnchor="middle" dominantBaseline="central" fill={textColor} fontSize={7.5} fontWeight={800} fontFamily="Inter,system-ui,sans-serif">{seat.id}</text>
      )}
      {!isBooked && !isSelected && seat.isExtraLegroom && (
        <text x={SEAT_W / 2} y={SEAT_H * 0.56} textAnchor="middle" dominantBaseline="central" fill={textColor} fontSize={10} fontWeight={800}>↕</text>
      )}
    </svg>
  );
};

const SeatIcon = memo(SeatIconComponent);

/* ═══════════════════════════════════════════════════════════
   EXIT DIVIDER
   ═══════════════════════════════════════════════════════════ */
const ExitDivider = () => (
  <div className="my-4 relative flex items-center justify-between">
    <span className="exit-label text-[8px] font-extrabold text-emerald-500 tracking-[0.18em] flex items-center gap-0.5">
      <svg width="7" height="7" viewBox="0 0 8 8" fill="none"><path d="M6 1L2 4L6 7" stroke="#10B981" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
      EXIT
    </span>
    <div className="flex-1 mx-2">
      <div className="h-[1px] bg-gradient-to-r from-emerald-200 via-slate-200 to-emerald-200" />
    </div>
    <span className="exit-label text-[8px] font-extrabold text-emerald-500 tracking-[0.18em] flex items-center gap-0.5">
      EXIT
      <svg width="7" height="7" viewBox="0 0 8 8" fill="none"><path d="M2 1L6 4L2 7" stroke="#10B981" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
    </span>
  </div>
);

/* ═══════════════════════════════════════════════════════════
   COCKPIT & TAIL ICONS
   ═══════════════════════════════════════════════════════════ */
const CockpitIcons = () => (
  <div className="flex items-center justify-center gap-2.5 pb-1">
    {[
      <path key="p" d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 7a4 4 0 1 0 0-0.01M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />,
      <><path key="c1" d="M17 8h1a4 4 0 1 1 0 8h-1" /><path key="c2" d="M3 8h14v9a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4Z" /><line key="c3" x1="6" y1="2" x2="6" y2="4" /><line key="c4" x1="10" y1="2" x2="10" y2="4" /><line key="c5" x1="14" y1="2" x2="14" y2="4" /></>,
      <><rect key="s1" x="2" y="7" width="20" height="14" rx="2" ry="2" /><path key="s2" d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" /></>,
    ].map((paths, i) => (
      <div key={i} className="w-[26px] h-[26px] rounded-md bg-slate-50/80 border border-slate-100 flex items-center justify-center">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">{paths}</svg>
      </div>
    ))}
  </div>
);

const TailIcons = () => (
  <div className="flex items-center justify-center gap-2 pt-1">
    {[0, 1, 2, 3].map((i) => (
      <div key={i} className="w-[22px] h-[22px] rounded bg-slate-50/60 border border-slate-100 flex items-center justify-center">
        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#CBD5E1" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          {i < 2 ? (
            <><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /></>
          ) : (
            <><path d="M17 8h1a4 4 0 1 1 0 8h-1" /><path d="M3 8h14v9a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4Z" /></>
          )}
        </svg>
      </div>
    ))}
  </div>
);

/* ═══════════════════════════════════════════════════════════
   LAVATORY (WC) & GALLEY (Kitchen)
   ═══════════════════════════════════════════════════════════ */
const Lavatory = () => (
  <div className="w-[30px] h-[34px] bg-slate-100 border border-slate-200 rounded-md flex flex-col items-center justify-center shadow-sm">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#64748B" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M4 10V22"/><path d="M4 14h6"/><path d="M10 10V22"/><path d="M14 10V22"/><path d="M14 14h6"/><path d="M20 10V22"/><circle cx="7" cy="5" r="2"/><circle cx="17" cy="5" r="2"/>
    </svg>
    <span className="text-[7px] font-bold text-slate-500 mt-0.5 tracking-wider">WC</span>
  </div>
);

const Galley = () => (
  <div className="w-[40px] h-[34px] bg-slate-100 border border-slate-200 rounded-md flex flex-col items-center justify-center shadow-sm">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#64748B" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M11 20A7 7 0 0 1 9.9 6.1C15.5 5 17 4.48 19 2v6.5a5 5 0 0 1-2.91 4.53C15.63 13.28 16 13.93 16 14.5A2.5 2.5 0 0 1 13.5 17c-.17 0-.33-.02-.5-.05A7 7 0 0 1 11 20Z"/><path d="M11 20v-3"/><path d="M11 20v-3"/><path d="M6 14h2"/><path d="M6 18h2"/>
    </svg>
    <span className="text-[7px] font-bold text-slate-500 mt-0.5 tracking-wider">GALLEY</span>
  </div>
);

/* ═══════════════════════════════════════════════════════════
   CLASS DIVIDER (Bulkhead)
   ═══════════════════════════════════════════════════════════ */
const ClassDivider = ({ label }: { label: string }) => (
  <div className="my-5 relative flex flex-col items-center justify-center w-full">
    <div className="flex w-full px-8 items-center justify-between opacity-50">
      <div className="w-[80px] h-[3px] bg-slate-300 rounded-full" />
      <div className="w-[80px] h-[3px] bg-slate-300 rounded-full" />
    </div>
    <div className="absolute top-1/2 -translate-y-1/2 bg-[#F8FAFC] px-3 py-1 border border-slate-200 rounded-full">
      <span className="text-[9px] font-extrabold text-slate-500 tracking-[0.1em] uppercase">
        {label}
      </span>
    </div>
  </div>
);

/* ═══════════════════════════════════════════════════════════
   MAIN COMPONENT — SeatMap2D
   ═══════════════════════════════════════════════════════════ */
interface SeatMap2DProps {
  seats: Seat[];
  selectedSeats: Seat[];
  onSelectSeat: (seat: Seat) => void;
  activeFilters?: string[];
  variant?: "normal" | "zoomed";
  selectedCabinClass?: CabinClass;
}

export const SeatMap2D = ({ seats, selectedSeats, onSelectSeat, activeFilters = [], variant = "normal", selectedCabinClass }: SeatMap2DProps) => {
  const [hoveredSeatId, setHoveredSeatId] = useState<string | null>(null);

  const getSeat = useCallback(
    (row: number, col: string) => seats.find((s) => s.row === row && s.column === col) ?? null,
    [seats]
  );

  /* ── Single seat ── */
  const renderSeat = (row: number, col: string) => {
    const seat = getSeat(row, col);
    if (!seat) return <div className="w-[26px] h-[30px]" key={`${row}${col}`} />;

    const isSelected = selectedSeats.some(s => s.id === seat.id);
    const isBooked = seat.status === "booked";
    const isHovered = hoveredSeatId === seat.id;

    // Check if seat matches the selected cabin class
    const matchesCabinClass = !selectedCabinClass || seat.cabinClass === selectedCabinClass;
    // For Economy class, also include Extra Legroom seats
    const isClassMatch = matchesCabinClass || (selectedCabinClass === "Economy" && seat.cabinClass === "Economy");

    // Check if seat matches filters
    let matchesFilters = true;
    if (activeFilters.length > 0) {
      const isWindow = seat.column === "A" || seat.column === "F";
      const isAisle = ["C", "D"].includes(seat.column);
      const isPremium = seat.cabinClass === "Business" || seat.cabinClass === "Premium Economy";
      
      const filterChecks = activeFilters.map(f => {
        if (f === "Window") return isWindow;
        if (f === "Aisle") return isAisle;
        if (f === "Extra Legroom") return seat.isExtraLegroom;
        if (f === "Near Exit") return seat.features.includes("Near Exit");
        if (f === "Premium") return isPremium;
        return true;
      });
      matchesFilters = filterChecks.every(Boolean);
    }

    const isDimmedByFilter = activeFilters.length > 0 && !matchesFilters;
    const isDimmedByClass = !isClassMatch;
    const isDimmed = isDimmedByFilter || isDimmedByClass;
    const isDisabled = isBooked || isDimmedByClass;

    let glowClass = "";
    if (isHovered && !isBooked && !isSelected && !isDimmedByClass) {
      if (seat.cabinClass === "Business") glowClass = "shadow-[0_0_10px_rgba(167,139,250,0.55)]";
      else if (seat.cabinClass === "Premium Economy") glowClass = "shadow-[0_0_10px_rgba(59,130,246,0.5)]";
      else if (seat.isExtraLegroom) glowClass = "shadow-[0_0_10px_rgba(52,211,153,0.45)]";
      else glowClass = "shadow-[0_0_10px_rgba(99,102,241,0.35)]";
    }

    return (
      <button
        key={seat.id}
        onMouseEnter={() => !isDimmedByClass && setHoveredSeatId(seat.id)}
        onMouseLeave={() => setHoveredSeatId(null)}
        onClick={() => !isDisabled && onSelectSeat(seat)}
        disabled={isDisabled}
        className={`seat-base relative rounded-md flex items-center justify-center group
          ${isDisabled ? "cursor-not-allowed" : "cursor-pointer"}
          ${isBooked && !isDimmedByClass ? "opacity-75" : ""}
          ${isSelected ? "seat-selected-glow" : ""}
          ${isDimmed ? "opacity-[0.15] grayscale pointer-events-none" : ""}
          ${glowClass}`}
        style={isDimmedByClass ? { pointerEvents: "none" } : undefined}
        aria-label={`Seat ${seat.id}${isBooked ? " occupied" : isDimmedByClass ? " (different class)" : ` $${seat.price}`}`}
      >
        <div className={`transition-transform duration-200 ${!isDisabled && !isSelected ? "group-hover:scale-[1.08] group-active:scale-95" : ""}`}>
          <SeatIcon seat={seat} isSelected={isSelected} isHovered={isHovered} />
        </div>
        
        {/* INLINE TOOLTIP - perfectly positioned relative to the seat */}
        {isHovered && !isDimmedByClass && (
          <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 z-[60]">
             <SeatTooltip seat={seat} />
          </div>
        )}
      </button>
    );
  };

  /* ── Row ── */
  const renderRow = (rowNum: number, leftCols: string[], rightCols: string[], middleCols: string[] = []) => (
    <div key={rowNum} className="flex items-center justify-center mb-[5px]">
      <div className="flex gap-1">{leftCols.map((c) => renderSeat(rowNum, c))}</div>
      {middleCols.length > 0 ? (
        <>
          <div className="w-8 flex items-center justify-center">
            <span className="text-[9px] font-bold text-slate-600 select-none">{rowNum}</span>
          </div>
          <div className="flex gap-1">{middleCols.map((c) => renderSeat(rowNum, c))}</div>
          <div className="w-4" />
          <div className="flex gap-1">{rightCols.map((c) => renderSeat(rowNum, c))}</div>
        </>
      ) : (
        <>
          <div className="w-12 flex items-center justify-center">
            <span className="text-[9px] font-bold text-slate-600 select-none">{rowNum}</span>
          </div>
          <div className="flex gap-1">{rightCols.map((c) => renderSeat(rowNum, c))}</div>
        </>
      )}
    </div>
  );

  /* ── Column Labels ── */
  const renderLabels = (leftCols: string[], rightCols: string[], middleCols: string[] = []) => (
    <div className="flex items-center justify-center mb-2 text-[9px] font-bold text-slate-400 tracking-wider select-none">
      <div className="flex gap-1">
        {leftCols.map((c) => (<div key={c} className="w-[26px] text-center">{c}</div>))}
      </div>
      {middleCols.length > 0 ? (
        <>
          <div className="w-8" />
          <div className="flex gap-1">{middleCols.map((c) => (<div key={c} className="w-[26px] text-center">{c}</div>))}</div>
          <div className="w-4" />
          <div className="flex gap-1">{rightCols.map((c) => (<div key={c} className="w-[26px] text-center">{c}</div>))}</div>
        </>
      ) : (
        <>
          <div className="w-12" />
          <div className="flex gap-1">{rightCols.map((c) => (<div key={c} className="w-[26px] text-center">{c}</div>))}</div>
        </>
      )}
    </div>
  );

  /* ══════════════════════════════════════════════════════════
     RENDER
     ══════════════════════════════════════════════════════════ */
  return (
    <div className="relative w-[400px] pt-4">
      {/* ── SVG AIRPLANE FUSELAGE ── */}
      <div className="absolute inset-0 pointer-events-none">
        <svg viewBox="0 0 400 1400" preserveAspectRatio="none" className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="fuse-grad" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#EEF2F6" />
              <stop offset="50%" stopColor="#FFFFFF" />
              <stop offset="100%" stopColor="#EEF2F6" />
            </linearGradient>
            <filter id="fuse-shadow" x="-8%" y="-1%" width="116%" height="103%">
              <feDropShadow dx="0" dy="3" stdDeviation="6" floodColor="#94A3B8" floodOpacity="0.13" />
            </filter>
            <linearGradient id="wing-g" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#E2E8F0" />
              <stop offset="100%" stopColor="#D1D7E0" />
            </linearGradient>
          </defs>

          {/* ── Outer Fuselage ── */}
          <path
            d="M 200 16
               C 278 16, 330 72, 336 158
               L 338 1195
               C 338 1278, 268 1342, 200 1375
               C 132 1342, 62 1278, 62 1195
               L 64 158
               C 70 72, 122 16, 200 16 Z"
            fill="url(#fuse-grad)"
            stroke="#D8DEE6"
            strokeWidth="2"
            filter="url(#fuse-shadow)"
          />

          {/* ── Inner Cabin ── */}
          <path
            d="M 200 36
               C 268 36, 314 80, 318 162
               L 320 1188
               C 320 1262, 258 1318, 200 1346
               C 142 1318, 80 1262, 80 1188
               L 82 162
               C 86 80, 132 36, 200 36 Z"
            fill="#FFFFFF"
            stroke="#EDF0F4"
            strokeWidth="1.5"
          />

          {/* ── Cockpit Windows ── */}
          <ellipse cx="178" cy="50" rx="5.5" ry="3.5" fill="#C8D0DA" stroke="#A0AABB" strokeWidth="0.8" />
          <ellipse cx="200" cy="45" rx="5.5" ry="3.5" fill="#C8D0DA" stroke="#A0AABB" strokeWidth="0.8" />
          <ellipse cx="222" cy="50" rx="5.5" ry="3.5" fill="#C8D0DA" stroke="#A0AABB" strokeWidth="0.8" />
          {/* Cockpit divider */}
          <path d="M 160 60 Q 200 68, 240 60" stroke="#D8DEE6" strokeWidth="0.8" fill="none" />

          {/* ── Left Wing ── */}
          <path d="M 64 530 L 2 680 Q -4 698, 4 702 L 10 699 L 64 615 Z" fill="url(#wing-g)" stroke="#C8D0DA" strokeWidth="1.2" />
          {/* Left engine */}
          <ellipse cx="22" cy="675" rx="10" ry="18" fill="#E5E9EF" stroke="#C8D0DA" strokeWidth="1" />
          <ellipse cx="22" cy="675" rx="5" ry="10" fill="#F1F5F9" stroke="#D4D9E0" strokeWidth="0.6" />

          {/* ── Right Wing ── */}
          <path d="M 336 530 L 398 680 Q 404 698, 396 702 L 390 699 L 336 615 Z" fill="url(#wing-g)" stroke="#C8D0DA" strokeWidth="1.2" />
          {/* Right engine */}
          <ellipse cx="378" cy="675" rx="10" ry="18" fill="#E5E9EF" stroke="#C8D0DA" strokeWidth="1" />
          <ellipse cx="378" cy="675" rx="5" ry="10" fill="#F1F5F9" stroke="#D4D9E0" strokeWidth="0.6" />

          {/* ── Tail Stabilizers ── */}
          <path d="M 200 1346 L 172 1380 L 160 1398 L 175 1392 L 200 1378 Z" fill="#E2E8F0" stroke="#CBD5E1" strokeWidth="0.8" />
          <path d="M 200 1346 L 228 1380 L 240 1398 L 225 1392 L 200 1378 Z" fill="#E2E8F0" stroke="#CBD5E1" strokeWidth="0.8" />
          {/* Vertical stabilizer */}
          <path d="M 197 1350 L 197 1395 L 200 1400 L 203 1395 L 203 1350 Z" fill="#D8DEE6" stroke="#CBD5E1" strokeWidth="0.6" />

          {/* ── EXIT Door Indicators ── */}
          <rect x="60" y="485" width="6" height="18" rx="2" fill="#D1FAE5" stroke="#86EFAC" strokeWidth="0.8" />
          <rect x="334" y="485" width="6" height="18" rx="2" fill="#D1FAE5" stroke="#86EFAC" strokeWidth="0.8" />
          <rect x="60" y="780" width="6" height="18" rx="2" fill="#D1FAE5" stroke="#86EFAC" strokeWidth="0.8" />
          <rect x="334" y="780" width="6" height="18" rx="2" fill="#D1FAE5" stroke="#86EFAC" strokeWidth="0.8" />

          {/* ── Fuselage Window Dots ── */}
          {Array.from({ length: 30 }, (_, i) => (
            <React.Fragment key={`wd${i}`}>
              <circle cx="74" cy={160 + i * 38} r="2" fill="#F0F2F5" stroke="#DCE0E6" strokeWidth="0.4" />
              <circle cx="326" cy={160 + i * 38} r="2" fill="#F0F2F5" stroke="#DCE0E6" strokeWidth="0.4" />
            </React.Fragment>
          ))}
        </svg>
      </div>

      {/* ── SEAT CONTENT ── */}
      <div className="relative z-10 pb-12">
        {/* Cockpit icons */}
        <div className="h-[52px] flex items-end justify-center pb-1">
          <CockpitIcons />
        </div>

        {/* Front Galley & Lavatory */}
        <div className="flex justify-center gap-8 py-3 opacity-90">
          <Lavatory />
          <Galley />
          <Lavatory />
        </div>

        <div className="py-3">
          {/* ─── BUSINESS CLASS (rows 1-7) ─── */}
          {renderLabels(["A", "C"], ["D", "F"])}
          {Array.from({ length: 7 }, (_, i) => i + 1).map((r) =>
            renderRow(r, ["A", "C"], ["D", "F"])
          )}

          <ClassDivider label="Premium Economy" />

          {/* ─── PREMIUM ECONOMY (rows 10-14) ─── */}
          {renderLabels(["A", "B"], ["E", "F"], ["C", "D"])}
          {Array.from({ length: 5 }, (_, i) => i + 10).map((r) =>
            renderRow(r, ["A", "B"], ["E", "F"], ["C", "D"])
          )}

          {/* EXIT & Middle Lavatories */}
          <div className="relative">
            <ExitDivider />
            <div className="absolute top-1/2 -translate-y-1/2 left-[50px] opacity-80">
              <Lavatory />
            </div>
            <div className="absolute top-1/2 -translate-y-1/2 right-[50px] opacity-80">
              <Lavatory />
            </div>
          </div>

          <ClassDivider label="Economy Class" />

          {/* ─── ECONOMY: Extra Legroom (15-17) + Regular (18-30) ─── */}
          {renderLabels(["A", "B", "C"], ["D", "E", "F"])}
          {Array.from({ length: 16 }, (_, i) => i + 15).map((r) =>
            renderRow(r, ["A", "B", "C"], ["D", "E", "F"])
          )}
        </div>

        {/* Rear Galley & Lavatory */}
        <div className="flex justify-center gap-8 py-3 opacity-90">
          <Lavatory />
          <Galley />
          <Lavatory />
        </div>

        {/* Tail icons */}
        <div className="h-[45px] flex items-start justify-center pt-1">
          <TailIcons />
        </div>
      </div>
    </div>
  );
};
