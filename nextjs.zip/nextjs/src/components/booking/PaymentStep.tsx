"use client";

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { BookingSummaryType, CABIN_CLASS_PRICE_ADDON } from "../../types/booking";
import { BookingSummary } from "./BookingSummary";
import { CreditCard, Wallet, Smartphone, ShieldCheck, Tag, Loader2 } from "lucide-react";

interface PaymentStepProps {
  summary: BookingSummaryType;
  onComplete: () => void;
}

export const PaymentStep = ({ summary, onComplete }: PaymentStepProps) => {
  const [method, setMethod] = useState<"card" | "upi" | "wallet">("card");
  const [isProcessing, setIsProcessing] = useState(false);
  const [promoCode, setPromoCode] = useState("");
  const [discount, setDiscount] = useState(0);
  const [promoError, setPromoError] = useState("");

  const [cardDetails, setCardDetails] = useState({
    name: "John Smith",
    number: "4242 4242 4242 4242",
    expiry: "12 / 28",
    cvv: "123",
  });

  const numSeats = summary.selectedSeats.length || 1;
  const cabinAddon = CABIN_CLASS_PRICE_ADDON[summary.selectedCabinClass] || 0;
  const baseTotal =
    ((summary.flight?.baseFare || 0) + cabinAddon) * numSeats +
    summary.selectedSeats.reduce((sum, seat) => sum + seat.price, 0) +
    summary.taxesAndFees;

  const total = Math.max(0, baseTotal - discount);

  const handleApplyPromo = () => {
    if (promoCode.toUpperCase() === "AERO20") {
      setDiscount(20);
      setPromoError("");
    } else if (promoCode.trim() === "") {
      setDiscount(0);
      setPromoError("");
    } else {
      setDiscount(0);
      setPromoError("Invalid promo code");
    }
  };

  const handlePay = () => {
    setIsProcessing(true);
    // Simulate network delay
    setTimeout(() => {
      onComplete();
    }, 1500);
  };

  return (
    <div className="flex gap-6 h-[calc(100vh-220px)] overflow-y-auto pb-10">
      {/* Main Content */}
      <div className="flex-1 min-w-0">
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6"
        >
          <h2 className="font-bold text-base mb-4">Choose payment method</h2>

          {/* Payment Tabs */}
          <div className="flex gap-3 mb-6">
            <button
              onClick={() => setMethod("card")}
              className={`flex-1 py-2.5 rounded-lg border-2 font-semibold text-xs flex items-center justify-center gap-2 transition-colors ${
                method === "card"
                  ? "border-blue-600 bg-blue-50/30 text-blue-700"
                  : "border-gray-200 text-gray-600 hover:bg-gray-50 font-medium"
              }`}
            >
              <CreditCard className="w-4 h-4" />
              Card
            </button>
            <button
              onClick={() => setMethod("upi")}
              className={`flex-1 py-2.5 rounded-lg border-2 font-semibold text-xs flex items-center justify-center gap-2 transition-colors ${
                method === "upi"
                  ? "border-blue-600 bg-blue-50/30 text-blue-700"
                  : "border-gray-200 text-gray-600 hover:bg-gray-50 font-medium"
              }`}
            >
              <Smartphone className="w-4 h-4" />
              UPI
            </button>
            <button
              onClick={() => setMethod("wallet")}
              className={`flex-1 py-2.5 rounded-lg border-2 font-semibold text-xs flex items-center justify-center gap-2 transition-colors ${
                method === "wallet"
                  ? "border-blue-600 bg-blue-50/30 text-blue-700"
                  : "border-gray-200 text-gray-600 hover:bg-gray-50 font-medium"
              }`}
            >
              <Wallet className="w-4 h-4" />
              Wallet
            </button>
          </div>

          <p className="text-xs text-gray-500 mb-4">
            {method === "card" && "Pay securely using your card"}
            {method === "upi" && "Scan QR or enter UPI ID"}
            {method === "wallet" && "Link your digital wallet"}
          </p>

          <AnimatePresence mode="wait">
            {method === "card" && (
              <motion.div
                key="card"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-4"
              >
                <div>
                  <label className="block text-[11px] text-gray-500 mb-1">Cardholder name</label>
                  <div className="relative">
                    <input
                      type="text"
                      value={cardDetails.name}
                      onChange={(e) => setCardDetails({ ...cardDetails, name: e.target.value })}
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none pr-10"
                    />
                    {cardDetails.name.length > 2 && <svg className="w-4 h-4 text-green-500 absolute right-3 top-2.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 13l4 4L19 7"/></svg>}
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] text-gray-500 mb-1">Card number</label>
                  <div className="relative">
                    <input
                      type="text"
                      value={cardDetails.number}
                      onChange={(e) => setCardDetails({ ...cardDetails, number: e.target.value })}
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 pl-12 text-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none pr-10 font-mono"
                    />
                    <div className="absolute left-3 top-2.5 text-blue-700 font-bold text-[10px] tracking-tighter">
                      {cardDetails.number.startsWith("4") ? "VISA" : cardDetails.number.startsWith("5") ? "MC" : "CARD"}
                    </div>
                    {cardDetails.number.length >= 15 && <svg className="w-4 h-4 text-green-500 absolute right-3 top-2.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 13l4 4L19 7"/></svg>}
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-1">
                    <label className="block text-[11px] text-gray-500 mb-1">Expiry date</label>
                    <div className="relative">
                      <input
                        type="text"
                        value={cardDetails.expiry}
                        onChange={(e) => setCardDetails({ ...cardDetails, expiry: e.target.value })}
                        className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none pr-10"
                      />
                    </div>
                  </div>
                  <div className="flex-1">
                    <label className="flex items-center gap-1 text-[11px] text-gray-500 mb-1">
                      CVV <span className="border border-gray-300 rounded-full w-3 h-3 flex items-center justify-center text-[7px] cursor-help">i</span>
                    </label>
                    <div className="relative">
                      <input
                        type="password"
                        value={cardDetails.cvv}
                        onChange={(e) => setCardDetails({ ...cardDetails, cvv: e.target.value })}
                        className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none pr-10"
                      />
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {method === "upi" && (
              <motion.div
                key="upi"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="py-10 text-center"
              >
                <div className="w-32 h-32 mx-auto bg-gray-100 rounded-lg mb-4 flex items-center justify-center border-2 border-dashed border-gray-300">
                  <Smartphone className="w-8 h-8 text-gray-400" />
                </div>
                <div className="text-sm font-medium text-gray-900 mb-1">Scan to pay</div>
                <div className="text-xs text-gray-500">Open any UPI app to scan and pay</div>
              </motion.div>
            )}

            {method === "wallet" && (
              <motion.div
                key="wallet"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="py-8"
              >
                <div className="flex gap-4">
                  <button className="flex-1 py-4 border border-gray-200 rounded-xl hover:border-blue-500 hover:bg-blue-50 flex flex-col items-center justify-center gap-2 transition-colors">
                    <div className="w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-bold text-xs">PP</div>
                    <span className="text-xs font-semibold">PayPal</span>
                  </button>
                  <button className="flex-1 py-4 border border-gray-200 rounded-xl hover:border-blue-500 hover:bg-blue-50 flex flex-col items-center justify-center gap-2 transition-colors">
                    <div className="w-8 h-8 bg-black text-white rounded-full flex items-center justify-center font-bold text-xs"></div>
                    <span className="text-xs font-semibold">Apple Pay</span>
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="pt-6 mt-6 border-t border-gray-100">
            <label className="block text-[11px] text-gray-500 mb-1">Promo code (Try: AERO20)</label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Tag className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={promoCode}
                  onChange={(e) => setPromoCode(e.target.value)}
                  placeholder="Enter promo code"
                  className={`w-full border rounded-lg px-3 py-2 pl-9 text-sm focus:ring-1 outline-none ${
                    promoError ? "border-red-300 focus:border-red-500 focus:ring-red-500" : "border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                  }`}
                />
              </div>
              <button 
                onClick={handleApplyPromo}
                className="px-5 py-2 rounded-lg border border-blue-200 text-blue-600 text-sm font-medium hover:bg-blue-50 transition-colors"
              >
                Apply
              </button>
            </div>
            {promoError && <div className="text-[10px] text-red-500 mt-1">{promoError}</div>}
            {discount > 0 && <div className="text-[10px] text-green-600 mt-1 font-medium">Promo code applied: -USD ${discount.toFixed(2)}</div>}
          </div>

          {/* Saved Cards */}
          {method === "card" && (
            <div className="mt-6 border-t border-gray-100 pt-5">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-1 text-xs font-semibold text-gray-700">
                  Saved cards <span className="border border-gray-300 rounded-full w-3 h-3 flex items-center justify-center text-[7px] cursor-help">i</span>
                </div>
                <button className="text-xs font-medium text-blue-600 hover:underline">Manage cards</button>
              </div>

              <div className="flex gap-3 overflow-x-auto pb-2">
                {/* Card 1 */}
                <div 
                  onClick={() => setCardDetails({ name: "John Smith", number: "4242 4242 4242 4242", expiry: "12 / 28", cvv: "123" })}
                  className={`flex-1 min-w-[140px] rounded-xl p-3 relative cursor-pointer transition-all ${cardDetails.number.startsWith("4242") ? "border-2 border-blue-500 bg-blue-50/30" : "border border-gray-200 hover:border-gray-300"}`}
                >
                  {cardDetails.number.startsWith("4242") && <div className="w-3 h-3 rounded-full bg-blue-600 border-2 border-white absolute top-3 left-3 shadow-sm" />}
                  <div className={`font-bold text-xs tracking-tighter ${cardDetails.number.startsWith("4242") ? "text-blue-700 ml-6" : "text-gray-500"}`}>VISA</div>
                  <div className="text-xs font-bold mt-2 tracking-widest text-gray-800">···· 4242</div>
                  <div className="text-[9px] text-gray-500 mt-0.5">Expires 12/28</div>
                </div>

                {/* Card 2 */}
                <div 
                  onClick={() => setCardDetails({ name: "John Smith", number: "5555 5555 5555 8888", expiry: "09 / 26", cvv: "456" })}
                  className={`flex-1 min-w-[140px] rounded-xl p-3 relative cursor-pointer transition-all ${cardDetails.number.endsWith("8888") ? "border-2 border-blue-500 bg-blue-50/30" : "border border-gray-200 hover:border-gray-300"}`}
                >
                  {cardDetails.number.endsWith("8888") && <div className="w-3 h-3 rounded-full bg-blue-600 border-2 border-white absolute top-3 left-3 shadow-sm" />}
                  <div className={`flex ${cardDetails.number.endsWith("8888") ? "ml-6" : ""}`}>
                    <div className="w-3.5 h-3.5 rounded-full bg-red-500/80 mix-blend-multiply" />
                    <div className="w-3.5 h-3.5 rounded-full bg-yellow-500/80 mix-blend-multiply -ml-1.5" />
                  </div>
                  <div className="text-xs font-bold mt-2 tracking-widest text-gray-800">···· 8888</div>
                  <div className="text-[9px] text-gray-500 mt-0.5">Expires 09/26</div>
                </div>
              </div>
            </div>
          )}

          <motion.button
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.99 }}
            onClick={handlePay}
            disabled={isProcessing}
            className={`w-full mt-6 text-white rounded-xl py-3.5 font-semibold flex items-center justify-center gap-2 shadow-lg transition-colors ${
              isProcessing ? "bg-blue-400 cursor-wait shadow-none" : "bg-[#005BFF] hover:bg-blue-700 shadow-blue-200"
            }`}
          >
            {isProcessing ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <ShieldCheck className="w-5 h-5" />
            )}
            {isProcessing ? "Processing Payment..." : `Pay USD ${total.toFixed(2)}`}
            {!isProcessing && <svg className="w-4 h-4 ml-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>}
          </motion.button>
        </motion.div>
      </div>

      {/* Right Sidebar */}
      <div className="w-[320px] flex-shrink-0">
        <BookingSummary summary={{...summary, discount}} currentStep="payment" />
      </div>
    </div>
  );
};
