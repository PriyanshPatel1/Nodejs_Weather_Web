"use client";

import React from "react";
import { motion } from "framer-motion";
import { Flight, CabinClass, BookingSummaryType, CABIN_CLASS_PRICE_ADDON } from "../../types/booking";
import { BookingSummary } from "./BookingSummary";
import { Plane, Clock, Award, Crown, Gem, Armchair } from "lucide-react";

interface FlightPlanStepProps {
  flights: Flight[];
  selectedFlight: Flight;
  onSelectFlight: (flight: Flight) => void;
  selectedCabinClass: CabinClass;
  onSelectCabinClass: (cabinClass: CabinClass) => void;
  summary: BookingSummaryType;
}

const cabinClassOptions: {
  value: CabinClass;
  label: string;
  priceLabel: string;
  icon: React.ReactNode;
  color: string;
  borderColor: string;
  bgColor: string;
  glowColor: string;
  features: string[];
}[] = [
  {
    value: "Business",
    label: "Business Class",
    priceLabel: "from $150",
    icon: <Crown className="w-5 h-5" />,
    color: "text-purple-600",
    borderColor: "border-purple-500",
    bgColor: "bg-purple-50",
    glowColor: "ring-purple-400/30",
    features: ["Lie-flat bed", "Premium meals", "Lounge access"],
  },
  {
    value: "Premium Economy",
    label: "Premium Economy",
    priceLabel: "from $50",
    icon: <Gem className="w-5 h-5" />,
    color: "text-blue-600",
    borderColor: "border-blue-500",
    bgColor: "bg-blue-50",
    glowColor: "ring-blue-400/30",
    features: ["Extra recline", "Priority boarding", "Enhanced meals"],
  },
  {
    value: "Economy",
    label: "Economy",
    priceLabel: "from $0",
    icon: <Armchair className="w-5 h-5" />,
    color: "text-slate-600",
    borderColor: "border-slate-400",
    bgColor: "bg-slate-50",
    glowColor: "ring-slate-400/20",
    features: ["Standard seat", "Complimentary snacks", "In-flight entertainment"],
  },
];

export const FlightPlanStep = ({
  flights,
  selectedFlight,
  onSelectFlight,
  selectedCabinClass,
  onSelectCabinClass,
  summary,
}: FlightPlanStepProps) => {
  const activeCabinOption = cabinClassOptions.find((o) => o.value === selectedCabinClass)!;

  return (
    <div className="flex gap-6">
      {/* Main Content */}
      <div className="flex-1 min-w-0">
        {/* Trip Overview Card */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 mb-6"
        >
          <h2 className="font-bold text-base mb-5">Your trip overview</h2>

          {/* Route Display */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex-1">
              <div className="text-4xl font-bold text-gray-900 tracking-tight">
                {selectedFlight.departureCode}
              </div>
              <div className="text-xs text-gray-600 mt-0.5">
                {selectedFlight.departureCity}
              </div>
              <div className="text-[10px] text-gray-400 leading-tight mt-0.5">
                Chhatrapati Shivaji<br />Maharaj Intl. Airport
              </div>
            </div>

            {/* Airplane illustration */}
            <div className="flex-1 mx-4 relative">
              <div className="border-t-[1.5px] border-dashed border-blue-300 relative">
                <div className="absolute left-0 top-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-blue-600 -ml-1" />
                <div className="absolute right-0 top-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-blue-600 -mr-1" />
              </div>
              <motion.div
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ duration: 0.8, ease: "easeOut" }}
                className="absolute left-1/2 -translate-x-1/2 -top-4"
              >
                <Plane className="w-8 h-8 text-blue-600" />
              </motion.div>
            </div>

            <div className="flex-1 text-right">
              <div className="text-4xl font-bold text-gray-900 tracking-tight">
                {selectedFlight.arrivalCode}
              </div>
              <div className="text-xs text-gray-600 mt-0.5">
                {selectedFlight.arrivalCity}
              </div>
              <div className="text-[10px] text-gray-400 leading-tight mt-0.5">
                Dubai International<br />Airport
              </div>
            </div>
          </div>

          {/* Time Info */}
          <div className="flex items-center justify-between mt-6">
            <div>
              <div className="text-xl font-bold">{selectedFlight.departureTime}</div>
              <div className="text-[10px] text-gray-500">{selectedFlight.date}</div>
            </div>
            <div className="flex flex-col items-center">
              <div className="flex items-center gap-1.5 text-[10px] text-gray-500 mb-1.5">
                <Clock className="w-3.5 h-3.5" />
                {selectedFlight.duration}
              </div>
              <div className="px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-600 text-[10px] font-medium">
                Non-stop
              </div>
            </div>
            <div className="text-right">
              <div className="text-xl font-bold">{selectedFlight.arrivalTime}</div>
              <div className="text-[10px] text-gray-500">{selectedFlight.date}</div>
            </div>
          </div>

          {/* Flight Details */}
          <div className="flex items-center justify-center gap-10 mt-6 pt-4 border-t border-gray-100 text-[10px] text-gray-600">
            <div className="flex items-center gap-2">
              <Plane className="w-3.5 h-3.5 text-gray-400" />
              <div>
                <div className="text-gray-400">Flight</div>
                <div className="font-medium text-xs text-gray-800">{selectedFlight.flightNumber}</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <svg className="w-3.5 h-3.5 text-gray-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="2" y="7" width="20" height="14" rx="2" />
                <path d="M16 7V5a4 4 0 00-8 0v2" />
              </svg>
              <div>
                <div className="text-gray-400">Aircraft</div>
                <div className="font-medium text-xs text-gray-800">{selectedFlight.aircraft}</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className={`${activeCabinOption.color}`}>
                {activeCabinOption.icon}
              </div>
              <div>
                <div className="text-gray-400">Cabin</div>
                <div className={`font-medium text-xs ${activeCabinOption.color}`}>
                  {activeCabinOption.label}
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* ──── Cabin Class Selector ──── */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
          className="mb-6"
        >
          <h2 className="font-bold text-base mb-3">Choose your cabin class</h2>
          <div className="grid grid-cols-3 gap-3">
            {cabinClassOptions.map((option, i) => {
              const isActive = selectedCabinClass === option.value;
              return (
                <motion.button
                  key={option.value}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.08, duration: 0.3 }}
                  onClick={() => onSelectCabinClass(option.value)}
                  className={`relative p-4 rounded-xl border-[1.5px] text-left transition-all duration-300 cursor-pointer group
                    ${isActive
                      ? `${option.borderColor} ${option.bgColor} shadow-md ring-2 ${option.glowColor}`
                      : "border-gray-200 bg-white hover:border-gray-300 hover:shadow-sm"
                    }`}
                >
                  {/* Active indicator dot */}
                  {isActive && (
                    <motion.div
                      layoutId="cabin-active-dot"
                      className={`absolute top-3 right-3 w-2.5 h-2.5 rounded-full ${option.borderColor.replace("border-", "bg-")}`}
                      transition={{ type: "spring", stiffness: 300, damping: 25 }}
                    />
                  )}

                  {/* Icon + Label */}
                  <div className={`mb-3 ${isActive ? option.color : "text-gray-400 group-hover:text-gray-500"} transition-colors`}>
                    {option.icon}
                  </div>
                  <div className={`text-sm font-bold mb-0.5 ${isActive ? "text-gray-900" : "text-gray-700"}`}>
                    {option.label}
                  </div>
                  <div className={`text-xs font-semibold mb-3 ${isActive ? option.color : "text-gray-400"}`}>
                    {option.priceLabel}
                  </div>

                  {/* Features */}
                  <div className="space-y-1.5">
                    {option.features.map((feature) => (
                      <div
                        key={feature}
                        className={`flex items-center gap-1.5 text-[10px] ${isActive ? "text-gray-600" : "text-gray-400"}`}
                      >
                        <svg className="w-3 h-3 flex-shrink-0" viewBox="0 0 12 12" fill="none">
                          <path
                            d="M2 6L5 9L10 3"
                            stroke={isActive ? option.borderColor.replace("border-", "").replace("500", "") === "purple-" ? "#9333ea" : option.borderColor.replace("border-", "").replace("500", "") === "blue-" ? "#2563eb" : "#64748b" : "#94a3b8"}
                            strokeWidth="1.5"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                        {feature}
                      </div>
                    ))}
                  </div>
                </motion.button>
              );
            })}
          </div>
        </motion.div>

        {/* Choose Flight */}
        <h2 className="font-bold text-base mb-3">Choose your flight</h2>
        <div className="space-y-2.5">
          {flights.map((flight, i) => {
            const isSelected = flight.id === selectedFlight.id;
            return (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1, duration: 0.3 }}
                key={flight.id}
                onClick={() => onSelectFlight(flight)}
                className={`bg-white rounded-xl border-[1.5px] p-4 cursor-pointer transition-all hover:shadow-sm ${
                  isSelected
                    ? "border-blue-600 shadow-sm bg-blue-50/20 ring-1 ring-blue-600/10"
                    : "border-gray-200 hover:border-blue-300"
                }`}
              >
                <div className="flex items-center justify-between">
                  {/* Radio + Flight Info */}
                  <div className="flex items-center gap-3 w-40">
                    <div
                      className={`w-4 h-4 rounded-full border-[1.5px] flex items-center justify-center transition-colors ${
                        isSelected ? "border-blue-600" : "border-gray-300"
                      }`}
                    >
                      {isSelected && <div className="w-2 h-2 rounded-full bg-blue-600" />}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5 text-blue-600">
                        <Plane className="w-3.5 h-3.5" />
                        <span className="font-bold text-sm text-gray-900">{flight.flightNumber}</span>
                      </div>
                      <div className="text-[10px] text-gray-400 mt-0.5">{flight.aircraft}</div>
                    </div>
                  </div>

                  {/* Departure */}
                  <div className="w-16">
                    <div className="font-bold text-sm">{flight.departureTime}</div>
                    <div className="text-[10px] text-gray-500">{flight.departureCode}</div>
                    <div className="text-[9px] text-gray-400">{flight.departureCity}</div>
                  </div>

                  {/* Duration Line */}
                  <div className="flex flex-col items-center flex-1 max-w-[120px] px-2">
                    <div className="text-[9px] text-gray-400">{flight.duration}</div>
                    <div className="w-full h-[1px] bg-gray-300 my-1 relative">
                      <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-1 rounded-full bg-gray-400" />
                      <div className="absolute right-0 top-1/2 -translate-y-1/2 w-1 h-1 rounded-full bg-gray-400" />
                    </div>
                    <div className="text-[9px] text-gray-400">Non-stop</div>
                  </div>

                  {/* Arrival */}
                  <div className="w-16">
                    <div className="font-bold text-sm">{flight.arrivalTime}</div>
                    <div className="text-[10px] text-gray-500">{flight.arrivalCode}</div>
                    <div className="text-[9px] text-gray-400">{flight.arrivalCity}</div>
                  </div>

                  {/* Price */}
                  <div className="text-right w-24">
                    <div className="font-bold text-base text-blue-600">USD {flight.baseFare + (CABIN_CLASS_PRICE_ADDON[selectedCabinClass] || 0)}</div>
                    {flight.bestValue && (
                      <div className="px-1.5 py-0.5 rounded text-[8px] font-bold bg-[#005BFF] text-white uppercase tracking-wider inline-flex items-center gap-0.5 mt-1">
                        <Award className="w-2.5 h-2.5" />
                        Best value
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Right Sidebar */}
      <BookingSummary summary={summary} currentStep="plan" />
    </div>
  );
};
