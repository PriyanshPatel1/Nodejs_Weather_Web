"use client";

import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Seat, CabinClass } from "../../types/booking";
import { SeatMap2D } from "./SeatMap2D";
import { Star, ShieldAlert, Armchair, Plane, Trash2 } from "lucide-react";

export type FilterType = "Window" | "Aisle" | "Extra Legroom" | "Near Exit" | "Premium";

interface SelectSeatStepProps {
  seats: Seat[];
  selectedSeats: Seat[];
  selectedCabinClass: CabinClass;
  onSelectSeat: (seat: Seat) => void;
  onContinue: () => void;
}

export const SelectSeatStep = ({
  seats,
  selectedSeats,
  selectedCabinClass,
  onSelectSeat,
  onContinue,
}: SelectSeatStepProps) => {
  const [activeFilters, setActiveFilters] = React.useState<FilterType[]>([]);

  const toggleFilter = (filter: FilterType) => {
    setActiveFilters((prev) =>
      prev.includes(filter) ? prev.filter((f) => f !== filter) : [...prev, filter]
    );
  };

  const clearSelection = () => {
    selectedSeats.forEach((seat) => onSelectSeat(seat));
  };

  const handleMapSeatClick = (seat: Seat) => {
    onSelectSeat(seat);
  };

  const totalUpgradePrice = selectedSeats.reduce((sum, seat) => sum + seat.price, 0);

  return (
    <div className="flex h-full px-8 gap-8 items-start justify-center pb-[100px]">
      {/* Left Column: Filters & Legend */}
      <div className="w-[240px] flex-shrink-0 space-y-6 pt-6">
        {/* Seat Categories */}
        <div>
          <h3 className="text-[11px] font-bold text-gray-500 uppercase tracking-widest mb-4">
            SEAT CATEGORIES
          </h3>
          <div className="space-y-4">
            <div className={`flex items-start gap-3 px-2 py-1.5 rounded-lg transition-all ${selectedCabinClass === "Business" ? "bg-purple-50 ring-1 ring-purple-200" : ""}`}>
              <div className="w-5 h-5 rounded bg-purple-100 border border-purple-200 mt-0.5" />
              <div>
                <div className={`text-xs font-bold ${selectedCabinClass === "Business" ? "text-purple-700" : "text-gray-900"}`}>Business</div>
                <div className="text-[10px] text-gray-500">1-7 Rows</div>
              </div>
              {selectedCabinClass === "Business" && <span className="ml-auto text-[8px] font-bold text-purple-600 bg-purple-100 px-1.5 py-0.5 rounded-full">ACTIVE</span>}
            </div>
            <div className={`flex items-start gap-3 px-2 py-1.5 rounded-lg transition-all ${selectedCabinClass === "Premium Economy" ? "bg-blue-50 ring-1 ring-blue-200" : ""}`}>
              <div className="w-5 h-5 rounded bg-blue-100 border border-blue-200 mt-0.5" />
              <div>
                <div className={`text-xs font-bold ${selectedCabinClass === "Premium Economy" ? "text-blue-700" : "text-gray-900"}`}>Premium Economy</div>
                <div className="text-[10px] text-gray-500">10-14 Rows</div>
              </div>
              {selectedCabinClass === "Premium Economy" && <span className="ml-auto text-[8px] font-bold text-blue-600 bg-blue-100 px-1.5 py-0.5 rounded-full">ACTIVE</span>}
            </div>
            <div className={`flex items-start gap-3 px-2 py-1.5 rounded-lg transition-all ${selectedCabinClass === "Economy" ? "bg-green-50 ring-1 ring-green-200" : ""}`}>
              <div className="w-5 h-5 rounded bg-green-100 border border-green-200 mt-0.5" />
              <div>
                <div className={`text-xs font-bold ${selectedCabinClass === "Economy" ? "text-green-700" : "text-gray-900"}`}>Extra Legroom</div>
                <div className="text-[10px] text-gray-500">15-17 Rows</div>
              </div>
            </div>
            <div className={`flex items-start gap-3 px-2 py-1.5 rounded-lg transition-all ${selectedCabinClass === "Economy" ? "bg-slate-50 ring-1 ring-slate-200" : ""}`}>
              <div className="w-5 h-5 rounded bg-gray-100 border border-gray-200 flex items-center justify-center mt-0.5">
                <span className="text-[8px] text-gray-400 font-bold">✕</span>
              </div>
              <div>
                <div className={`text-xs font-bold ${selectedCabinClass === "Economy" ? "text-slate-700" : "text-gray-900"}`}>Economy</div>
                <div className="text-[10px] text-gray-500">18-30 Rows</div>
              </div>
              {selectedCabinClass === "Economy" && <span className="ml-auto text-[8px] font-bold text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded-full">ACTIVE</span>}
            </div>
          </div>
        </div>

        {/* Filter Seats */}
        <div>
          <h3 className="text-[11px] font-bold text-gray-500 uppercase tracking-widest mb-4">
            FILTER SEATS
          </h3>
          <div className="space-y-3">
            {(
              [
                { icon: "0", label: "Window" },
                { icon: "||", label: "Aisle" },
                { icon: "↔", label: "Extra Legroom" },
                { icon: "EXIT", label: "Near Exit" },
                { icon: "★", label: "Premium" },
              ] as { icon: string; label: FilterType }[]
            ).map((filter) => {
              const isActive = activeFilters.includes(filter.label);
              return (
                <div
                  key={filter.label}
                  className="flex items-center justify-between cursor-pointer group"
                  onClick={() => toggleFilter(filter.label)}
                >
                  <div className="flex items-center gap-3 text-xs font-bold text-gray-700 group-hover:text-blue-600 transition-colors">
                    <span className="w-4 text-center text-gray-400 text-[10px] group-hover:text-blue-500">
                      {filter.icon}
                    </span>
                    {filter.label}
                  </div>
                  {/* Toggle switch */}
                  <div
                    className={`w-8 h-4 rounded-full relative transition-colors ${
                      isActive ? "bg-blue-500" : "bg-gray-200"
                    } shadow-inner`}
                  >
                    <div
                      className={`w-3.5 h-3.5 bg-white rounded-full shadow absolute top-[2px] transition-all ${
                        isActive ? "left-[16px]" : "left-[2px]"
                      }`}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Legend */}
        <div>
          <h3 className="text-[11px] font-bold text-gray-500 uppercase tracking-widest mb-4">
            SEAT LEGEND
          </h3>
          <div className="space-y-3">
            <div className="flex items-center gap-3 text-xs font-medium text-gray-600">
              <div className="w-4 h-4 rounded bg-white border border-gray-200" /> Available
            </div>
            <div className="flex items-center gap-3 text-xs font-medium text-gray-600">
              <div className="w-4 h-4 rounded bg-blue-600" /> Selected
            </div>
            <div className="flex items-center gap-3 text-xs font-medium text-gray-600">
              <div className="w-4 h-4 rounded bg-gray-200 flex items-center justify-center text-[8px] text-gray-400 font-bold">✕</div> Occupied
            </div>
            <div className="flex items-center gap-3 text-xs font-medium text-gray-600">
              <div className="w-4 h-4 rounded bg-gray-100 flex items-center justify-center text-[8px] text-gray-400 font-bold">/</div> Blocked
            </div>
            <div className="flex items-center gap-3 text-xs font-medium text-gray-600">
              <div className="w-4 h-4 rounded bg-green-100 border border-green-200 flex items-center justify-center text-green-500 font-bold text-[8px]">^</div> Extra Legroom
            </div>
            <div className="flex items-center gap-3 text-xs font-medium text-gray-600">
              <span className="text-green-500 font-bold text-[8px]">EXIT</span> Exit Row
            </div>
            <div className="flex items-center gap-3 text-xs font-medium text-gray-600">
              <Star className="w-4 h-4 text-orange-400 fill-orange-400" /> Premium Seat
            </div>
          </div>
        </div>
      </div>

      {/* Center Column: The Plane */}
      <div className="flex-1 flex justify-center max-w-[500px]">
        <SeatMap2D
          seats={seats}
          selectedSeats={selectedSeats}
          onSelectSeat={handleMapSeatClick}
          activeFilters={activeFilters}
          selectedCabinClass={selectedCabinClass}
        />
      </div>

      {/* Right Column: Seat Details */}
      <div className="w-[320px] flex-shrink-0 pt-6">
        <AnimatePresence mode="wait">
          {selectedSeats.length > 0 ? (
            <motion.div
              key="selected"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.3 }}
              className="bg-white rounded-2xl shadow-[0_8px_30px_rgb(0,0,0,0.04)] border border-gray-100 flex flex-col max-h-[80vh]"
            >
              <div className="p-5 border-b border-gray-100">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-bold text-[#0A1931]">Selected Seats</h3>
                  <span className="px-2.5 py-1 rounded-full bg-blue-50 text-blue-600 text-[10px] font-bold">
                    {selectedSeats.length} {selectedSeats.length === 1 ? "Seat" : "Seats"}
                  </span>
                </div>
              </div>

              <div className="p-5 overflow-y-auto flex-1 space-y-4">
                {selectedSeats.map((seat) => (
                  <div key={seat.id} className="p-4 rounded-xl border border-gray-100 bg-gray-50/50 relative group">
                    <button
                      onClick={() => onSelectSeat(seat)}
                      className="absolute top-3 right-3 text-gray-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <div className="text-xl font-bold text-[#0A1931]">{seat.id}</div>
                        <div className="text-[10px] text-gray-500 font-medium">
                          {seat.cabinClass} • {seat.column === "A" || seat.column === "F" ? "Window" : seat.column === "C" || seat.column === "D" ? "Aisle" : "Middle"}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-bold text-blue-600">
                          {seat.price > 0 ? `+$${seat.price.toFixed(2)}` : "Free"}
                        </div>
                      </div>
                    </div>
                    {seat.features.length > 0 && (
                      <div className="flex flex-wrap gap-1.5 mt-2">
                        {seat.features.map((f, i) => (
                          <span key={i} className="text-[9px] px-2 py-0.5 rounded bg-white border border-gray-200 text-gray-600">
                            {f}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>

              <div className="p-5 border-t border-gray-100 bg-gray-50 rounded-b-2xl">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-sm font-semibold text-gray-600">Total Upgrade</span>
                  <span className="text-xl font-bold text-[#0A1931]">${totalUpgradePrice.toFixed(2)}</span>
                </div>
                <button
                  onClick={onContinue}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white rounded-xl py-3.5 text-sm font-bold shadow-lg shadow-blue-200 transition-colors mb-3"
                >
                  Confirm {selectedSeats.length} {selectedSeats.length === 1 ? "Seat" : "Seats"}
                </button>
                <button
                  onClick={clearSelection}
                  className="w-full bg-white hover:bg-gray-50 border border-gray-200 text-gray-700 rounded-xl py-2.5 text-xs font-bold transition-colors"
                >
                  Clear all selections
                </button>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="empty"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="h-full flex flex-col items-center justify-center pt-20 text-center px-6"
            >
              <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mb-6">
                <Armchair className="w-8 h-8 text-gray-300" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Select seats</h3>
              <p className="text-sm text-gray-500">
                Click on any available seats on the map to add them to your booking.
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
