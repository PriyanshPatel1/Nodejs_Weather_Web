"use client";

import React from "react";
import { motion } from "framer-motion";
import { BookingSummaryType, StepStatus, CABIN_CLASS_PRICE_ADDON } from "../../types/booking";
import { Plane, ShieldCheck, CheckCircle2 } from "lucide-react";

interface BookingSummaryProps {
  summary: BookingSummaryType;
  currentStep: StepStatus;
  onEditStep?: (step: StepStatus) => void;
}

export const BookingSummary = ({
  summary,
  currentStep,
  onEditStep,
}: BookingSummaryProps) => {
  const numSeats = summary.selectedSeats.length || 1;
  const cabinAddon = CABIN_CLASS_PRICE_ADDON[summary.selectedCabinClass] || 0;
  const baseFare = ((summary.flight?.baseFare || 0) + cabinAddon) * numSeats;
  const seatUpgrade = summary.selectedSeats.reduce((sum, seat) => sum + seat.price, 0);
  const taxes = summary.taxesAndFees;
  const discount = summary.discount || 0;
  const total = Math.max(0, baseFare + seatUpgrade + taxes - discount);

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.4 }}
      className="w-[280px] flex-shrink-0 space-y-4"
    >
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 sticky top-6">
        <h2 className="font-bold text-base mb-5">Booking summary</h2>

        {/* Passenger Info */}
        <div className="mb-4">
          <div className="flex items-center justify-between text-xs mb-2">
            <div className="flex items-center gap-2 font-medium text-gray-700">
              <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" />
                <circle cx="12" cy="7" r="4" />
              </svg>
              {numSeats} {numSeats === 1 ? "Passenger" : "Passengers"}
            </div>
            {currentStep !== "plan" && currentStep !== "confirmation" && onEditStep && (
              <button onClick={() => onEditStep("plan")} className="text-blue-600 font-medium hover:underline">Edit</button>
            )}
          </div>
          <div className="flex justify-between items-center text-xs pl-5.5">
            <span className="text-gray-900">{summary.passenger.name}</span>
            <span className="text-gray-500">{summary.passenger.type}</span>
          </div>
        </div>

        <div className="w-full h-[1px] bg-gray-100 mb-4" />

        {/* Flight Info */}
        <div className="mb-6">
          <div className="flex items-center justify-between text-xs mb-3">
            <div className="flex items-center gap-2 font-medium text-gray-700">
              <Plane className="w-3.5 h-3.5" />
              FLIGHT
            </div>
            {currentStep !== "plan" && currentStep !== "confirmation" && onEditStep && (
              <button onClick={() => onEditStep("plan")} className="text-blue-600 font-medium hover:underline">Edit</button>
            )}
          </div>

          {summary.flight && (
            <div className="text-xs">
              <div className="text-gray-500 mb-3">{summary.flight.date}</div>

              {currentStep === "plan" ? (
                /* Timeline View for Step 1 */
                <div className="relative pl-3 border-l-[1.5px] border-dashed border-gray-300 space-y-4 ml-1">
                  <div className="relative">
                    <div className="absolute -left-[19px] top-1 w-2.5 h-2.5 rounded-full bg-blue-600 ring-2 ring-white" />
                    <div className="font-bold">{summary.flight.departureTime} <span className="text-gray-500 font-normal ml-1">{summary.flight.departureCode}</span></div>
                    <div className="text-[10px] text-gray-400">{summary.flight.departureCity}</div>
                  </div>
                  <div className="relative">
                    <div className="absolute -left-[19px] top-1 w-2.5 h-2.5 rounded-full bg-blue-600 ring-2 ring-white" />
                    <div className="font-bold">{summary.flight.arrivalTime} <span className="text-gray-500 font-normal ml-1">{summary.flight.arrivalCode}</span></div>
                    <div className="text-[10px] text-gray-400">{summary.flight.arrivalCity}</div>
                  </div>
                  <div className="text-[10px] text-gray-400 pt-2 border-t border-gray-100 -ml-3">
                    {summary.flight.flightNumber} • Non-stop • {summary.flight.duration}<br />
                    {summary.flight.aircraft}<br />
                    Economy Class
                  </div>
                </div>
              ) : (
                /* Compact View for other steps */
                <div>
                  <div className="font-bold mb-1">{summary.flight.flightNumber}</div>
                  <div className="flex items-center gap-2 font-medium mb-1.5 text-sm">
                    {summary.flight.departureCode} <Plane className="w-3 h-3 text-blue-600" /> {summary.flight.arrivalCode}
                  </div>
                  <div className="text-[10px] text-gray-400 leading-relaxed">
                    {summary.flight.departureCity} to {summary.flight.arrivalCity}<br />
                    {summary.flight.departureTime} - {summary.flight.arrivalTime}<br />
                    {summary.flight.aircraft} • Non-stop
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Seat selection summary if applicable */}
        {currentStep === "payment" && summary.selectedSeats.length > 0 && (
          <>
            <div className="w-full h-[1px] bg-gray-100 mb-3" />
            <div className="text-xs mb-5">
              <div className="text-[10px] font-bold text-gray-400 tracking-wider mb-1">SEATS</div>
              <div className="space-y-1.5">
                {summary.selectedSeats.map(seat => (
                  <div key={seat.id} className="font-medium text-gray-900 flex justify-between">
                    <span>{seat.id} <span className="text-gray-500 font-normal">({seat.features[0] || seat.cabinClass})</span></span>
                    {seat.price > 0 && <span className="text-blue-600 font-bold">+${seat.price.toFixed(2)}</span>}
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        <div className="w-full h-[1px] bg-gray-100 mb-4" />

        {/* Fare Breakdown */}
        <div>
          <div className="text-[10px] font-bold text-gray-400 tracking-wider mb-3">
            FARE BREAKDOWN
          </div>
          <div className="space-y-2.5 text-xs text-gray-600 mb-4">
            <div className="flex justify-between">
              <span>Base Fare ({numSeats}x)</span>
              <span>USD {baseFare.toFixed(2)}</span>
            </div>
            {seatUpgrade > 0 && (
              <div className="flex justify-between">
                <span>Seat Upgrades</span>
                <span>USD {seatUpgrade.toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between items-center">
              <span className="flex items-center gap-1">
                Taxes & Fees <span className="border border-gray-300 rounded-full w-3 h-3 flex items-center justify-center text-[7px] text-gray-400">i</span>
              </span>
              <span>USD {taxes.toFixed(2)}</span>
            </div>
            {discount > 0 && (
              <div className="flex justify-between items-center text-green-600 font-medium pt-2">
                <span>Promo Discount</span>
                <span>-USD {discount.toFixed(2)}</span>
              </div>
            )}
          </div>

          <div className="flex justify-between items-center pt-3 border-t border-gray-200">
            <span className="font-bold text-sm text-blue-600 tracking-wide uppercase">Total</span>
            <span className="font-bold text-lg text-blue-600">USD {total.toFixed(2)}</span>
          </div>
        </div>

        {/* Trust Badges */}
        <div className="mt-5 space-y-3 bg-gray-50/50 rounded-xl p-3 border border-gray-100">
          <div className="flex items-start gap-2.5">
            <ShieldCheck className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
            <div>
              <div className="text-xs font-medium text-gray-800">Secure {currentStep === "payment" ? "payment" : "booking"}</div>
              <div className="text-[9px] text-gray-400">
                {currentStep === "payment" ? "Your payment details are encrypted and secure." : "Your data is protected"}
              </div>
            </div>
          </div>
          <div className="flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
            <div>
              <div className="text-xs font-medium text-gray-800">Best price guarantee</div>
              <div className="text-[9px] text-gray-400">We match any eligible price</div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};
