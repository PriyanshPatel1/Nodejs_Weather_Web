"use client";

import React from "react";
import { motion } from "framer-motion";
import { Plane, ChevronDown, Check, Gem, HeadphonesIcon } from "lucide-react";
import { BookingSummaryType } from "../../types/booking";

export const TripSidebar = ({ summary }: { summary: BookingSummaryType }) => {
  const [isDetailsOpen, setIsDetailsOpen] = React.useState(false);
  
  const flight = summary.flight;
  const numSeats = summary.selectedSeats.length || 1;
  const seatUpgrade = summary.selectedSeats.reduce((sum, seat) => sum + seat.price, 0);
  const baseFare = (flight?.baseFare || 0) * numSeats;
  const priorityBoarding = 10 * numSeats;
  const total = baseFare + seatUpgrade + priorityBoarding;

  const handleFeatureClick = (feature: string) => {
    alert(`${feature} feature will be available shortly!`);
  };

  return (
    <div className="w-[300px] min-h-screen bg-[#F8FAFC] border-r border-gray-200 flex flex-col p-5 fixed left-0 top-0 overflow-y-auto z-40">
      {/* Logo */}
      <div className="flex items-center gap-2 mb-6 ml-1">
        <div className="w-8 h-8 rounded bg-blue-600 flex items-center justify-center transform -skew-x-12">
          <Plane className="w-5 h-5 text-white transform skew-x-12 -rotate-45" />
        </div>
        <span className="font-bold text-lg tracking-tight text-[#0A1931]">
          AEROVISTA
        </span>
      </div>

      {/* Dark Trip Card */}
      <motion.div
        initial={{ y: 10, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="bg-[#0A1931] text-white rounded-2xl p-5 mb-5 shadow-lg"
      >
        <div className="flex justify-between items-center mb-1">
          <div className="text-3xl font-bold tracking-tight">BOM</div>
          <div className="flex-1 mx-4 flex items-center">
            <div className="h-[1px] bg-gray-500 flex-1" />
            <Plane className="w-4 h-4 text-gray-400 mx-2" />
            <div className="h-[1px] bg-gray-500 flex-1" />
          </div>
          <div className="text-3xl font-bold tracking-tight">DXB</div>
        </div>
        <div className="flex justify-between text-xs text-gray-400 mb-4">
          <span>Mumbai</span>
          <span>Dubai</span>
        </div>

        <div className="text-[11px] text-gray-400 mb-5">
          AI 247 <span className="mx-1">•</span> Boeing 787-9 Dreamliner
        </div>

        <div className="flex justify-between items-end mb-4">
          <div>
            <div className="text-[10px] text-gray-400 uppercase tracking-wider mb-1">
              Departure
            </div>
            <div className="text-base font-bold">09:30 PM</div>
            <div className="text-[10px] text-gray-400 mt-0.5">Tue, 20 May</div>
          </div>
          <div className="flex flex-col items-center pb-1">
            <Plane className="w-4 h-4 text-gray-500 mb-1" />
            <div className="text-[10px] text-gray-400">02h 20m</div>
          </div>
          <div className="text-right">
            <div className="text-[10px] text-gray-400 uppercase tracking-wider mb-1">
              Arrival
            </div>
            <div className="text-base font-bold">11:50 PM</div>
            <div className="text-[10px] text-gray-400 mt-0.5">Tue, 20 May</div>
          </div>
        </div>

        <div 
          onClick={() => setIsDetailsOpen(!isDetailsOpen)}
          className="border-t border-gray-700/50 pt-3 mt-2 flex justify-between items-center cursor-pointer hover:text-gray-300 transition-colors"
        >
          <span className="text-xs font-medium">Flight details</span>
          <ChevronDown className={`w-4 h-4 transition-transform duration-300 ${isDetailsOpen ? "rotate-180" : ""}`} />
        </div>
        
        {/* Expanded Flight Details */}
        {isDetailsOpen && flight && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            className="pt-4 mt-2 border-t border-gray-700/30 text-xs text-gray-400 space-y-2"
          >
            <div className="flex justify-between">
              <span>Aircraft</span>
              <span className="text-white">{flight.aircraft}</span>
            </div>
            <div className="flex justify-between">
              <span>Cabin</span>
              <span className="text-white">{summary.selectedSeats[0]?.cabinClass || "Economy"}</span>
            </div>
            <div className="flex justify-between">
              <span>Duration</span>
              <span className="text-white">{flight.duration}</span>
            </div>
          </motion.div>
        )}
      </motion.div>

      {/* Passengers */}
      <div className="bg-white rounded-2xl p-4 mb-4 border border-gray-100 shadow-sm">
        <div className="flex justify-between items-center mb-4">
          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">
            Passengers
          </span>
          <span className="text-[10px] text-gray-400 font-medium">{numSeats} {numSeats === 1 ? "Passenger" : "Passengers"}</span>
        </div>
        <div className="flex items-center gap-3 pb-4 border-b border-gray-100 mb-4">
          <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-bold shadow-sm">
            {numSeats}
          </div>
          <div>
            <div className="text-sm font-bold text-gray-900">John Smith</div>
            <div className="text-[11px] text-gray-500">Adult</div>
          </div>
        </div>

        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center gap-2 text-gray-500 text-xs">
            <span className="w-4 h-4 flex items-center justify-center border border-gray-300 rounded text-[8px] font-bold">C</span>
            CLASS
          </div>
          <span className="text-xs font-medium text-gray-900">Economy</span>
        </div>

        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2 text-gray-500 text-xs">
            <span className="w-4 h-4 flex items-center justify-center border border-gray-300 rounded text-[8px] font-bold">S</span>
            SEATS
          </div>
          {summary.selectedSeats.length > 0 ? (
            <div className="flex flex-col items-end">
              <span className="text-xs font-bold text-blue-600">
                {summary.selectedSeats.map(s => s.id).join(", ")}
              </span>
            </div>
          ) : (
            <span className="text-xs font-medium text-orange-500">
              Not selected
            </span>
          )}
        </div>
      </div>

      {/* Price Summary */}
      <div className="bg-white rounded-2xl p-5 mb-4 border border-gray-100 shadow-sm">
        <h3 className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-4">
          Price Summary
        </h3>
        <div className="space-y-3 text-xs text-gray-600 mb-5">
          <div className="flex justify-between">
            <span>Base Fare ({numSeats}x)</span>
            <span className="font-medium text-gray-900">
              USD ${baseFare.toFixed(2)}
            </span>
          </div>
          <div className="flex justify-between">
            <span>Seat Upgrades</span>
            <span className="font-medium text-gray-900">
              USD ${seatUpgrade.toFixed(2)}
            </span>
          </div>
          <div className="flex justify-between">
            <span>Priority Boarding ({numSeats}x)</span>
            <span className="font-medium text-gray-900">
              USD ${priorityBoarding.toFixed(2)}
            </span>
          </div>
        </div>
        <div className="flex justify-between items-center pt-4 border-t border-gray-100">
          <span className="font-bold text-gray-900">Total</span>
          <span className="font-bold text-blue-600 text-lg">
            USD ${total.toFixed(2)}
          </span>
        </div>
      </div>

      {/* Rewards */}
      <div 
        onClick={() => handleFeatureClick("Aerovista Rewards")}
        className="bg-purple-50/50 rounded-xl p-4 mb-4 border border-purple-100 flex items-center justify-between cursor-pointer hover:bg-purple-50 transition-colors"
      >
        <div className="flex items-center gap-3">
          <Gem className="w-6 h-6 text-purple-500" />
          <div>
            <div className="text-[10px] font-bold text-purple-600 uppercase tracking-wider">
              AEROVISTA REWARDS
            </div>
            <div className="text-xs text-gray-600 mt-0.5">
              You will earn 1,250 points
            </div>
          </div>
        </div>
        <span className="text-purple-400 text-lg">›</span>
      </div>

      {/* Help */}
      <div 
        onClick={() => handleFeatureClick("Live Chat Support")}
        className="mt-auto flex items-center justify-between p-2 cursor-pointer group"
      >
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-blue-50 flex items-center justify-center group-hover:bg-blue-100 transition-colors">
            <HeadphonesIcon className="w-4 h-4 text-blue-600" />
          </div>
          <div>
            <div className="text-[11px] text-gray-500">Need help?</div>
            <div className="text-xs font-semibold text-blue-600">
              Chat with us
            </div>
          </div>
        </div>
        <span className="text-gray-400 text-lg group-hover:text-blue-500 transition-colors">›</span>
      </div>
    </div>
  );
};
