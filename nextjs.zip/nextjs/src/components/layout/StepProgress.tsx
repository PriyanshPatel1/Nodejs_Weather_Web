"use client";

import React from "react";
import { motion } from "framer-motion";
import { Check } from "lucide-react";
import { StepStatus } from "../../types/booking";

const steps = [
  { id: "plan", label: "Plan", number: 1 },
  { id: "select-seat", label: "Select seat", number: 2 },
  { id: "payment", label: "Payment", number: 3 },
];

export const StepProgress = ({ currentStep }: { currentStep: StepStatus }) => {
  const currentIndex = steps.findIndex((s) => s.id === currentStep);

  return (
    <div className="flex items-center w-full max-w-2xl mx-auto mb-8 pt-2">
      {steps.map((step, index) => {
        const isCompleted = index < currentIndex;
        const isActive = index === currentIndex;
        const isUpcoming = index > currentIndex;

        return (
          <React.Fragment key={step.id}>
            <div className="flex items-center gap-2 relative">
              {/* Circle */}
              <motion.div
                initial={false}
                animate={{
                  scale: isActive ? 1.1 : 1,
                  backgroundColor: isCompleted || isActive ? "#005BFF" : "#f3f4f6",
                }}
                transition={{ type: "spring", stiffness: 500, damping: 30 }}
                className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold"
                style={{
                  color: isCompleted || isActive ? "white" : "#9ca3af",
                }}
              >
                {isCompleted ? <Check className="w-3.5 h-3.5" /> : step.number}
              </motion.div>
              {/* Label */}
              <span
                className={`text-xs font-medium whitespace-nowrap ${
                  isCompleted
                    ? "text-gray-700"
                    : isActive
                    ? "text-blue-600"
                    : "text-gray-400"
                }`}
              >
                {step.label}
              </span>

              {/* Active Indicator */}
              {isActive && (
                <motion.div
                  layoutId="stepIndicator"
                  className="absolute -bottom-3 left-0 w-full h-0.5 bg-blue-600 rounded-full"
                  transition={{ type: "spring", stiffness: 500, damping: 30 }}
                />
              )}
            </div>

            {/* Connector Line */}
            {index < steps.length - 1 && (
              <div className="flex-1 h-[2px] mx-3 bg-gray-200 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: isCompleted ? "100%" : "0%" }}
                  transition={{ duration: 0.5, ease: "easeInOut" }}
                  className="h-full bg-blue-600"
                />
              </div>
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
};
