"use client";

import React from "react";
import { motion } from "framer-motion";
import { ArrowRight, Armchair } from "lucide-react";
import { BookingSummaryType, StepStatus } from "../../types/booking";

interface BottomActionBarProps {
  currentStep: StepStatus;
  summary: BookingSummaryType;
  onContinue: () => void;
  disabled?: boolean;
}

export const BottomActionBar = ({
  currentStep,
  summary,
  onContinue,
  disabled,
}: BottomActionBarProps) => {
  if (currentStep === "payment") return null;

  const numSeats = summary.selectedSeats.length || 1;
  const baseFare = (summary.flight?.baseFare || 0) * numSeats;
  const seatUpgrade = summary.selectedSeats.reduce((sum, seat) => sum + seat.price, 0);
  const priorityBoarding = 10 * numSeats;
  const total = baseFare + seatUpgrade + priorityBoarding;

  const handleViewPriceDetails = () => {
    alert(`Price Details:\nBase Fare: $${baseFare.toFixed(2)}\nSeat Upgrade: $${seatUpgrade.toFixed(2)}\nPriority Boarding: $${priorityBoarding.toFixed(2)}\nTotal: $${total.toFixed(2)}`);
  };

  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.3, delay: 0.2 }}
      className="fixed bottom-0 left-[300px] right-0 bg-white border-t border-gray-100 px-8 py-4 flex items-center justify-between z-50 shadow-[0_-10px_30px_rgba(0,0,0,0.03)]"
    >
      <div className="flex items-center gap-12">
        {/* Selected Seat Info */}
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600">
            <Armchair className="w-5 h-5" />
          </div>
          {summary.selectedSeats.length > 0 ? (
            <div>
              <div className="text-sm font-bold text-gray-900">
                {summary.selectedSeats.map(s => s.id).join(", ")}
              </div>
              <div className="flex gap-2 text-xs font-medium mt-0.5">
                <span className="text-gray-500">{summary.selectedSeats.length} {summary.selectedSeats.length === 1 ? "Seat" : "Seats"} Selected</span>
              </div>
            </div>
          ) : (
            <div>
              <div className="text-sm font-bold text-gray-400">--</div>
              <div className="text-xs text-gray-400 mt-0.5">Not selected</div>
            </div>
          )}
        </div>

        {/* Seat Price */}
        <div className="border-l border-gray-200 pl-8">
          <div className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-1">
            Seat Upgrades
          </div>
          <div className="text-sm font-bold text-gray-900">
            USD ${seatUpgrade.toFixed(2)}
          </div>
        </div>
      </div>

      <div className="flex items-center gap-8">
        {/* Total */}
        <div className="text-right">
          <div className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-1">
            Total
          </div>
          <div className="text-lg font-bold text-blue-600">
            USD ${total.toFixed(2)}
          </div>
          <div onClick={handleViewPriceDetails} className="text-[10px] text-gray-500 flex items-center justify-end gap-1 cursor-pointer hover:text-gray-700">
            View price details <span className="text-lg leading-none">›</span>
          </div>
        </div>

        <motion.button
          whileHover={!disabled ? { scale: 1.02 } : {}}
          whileTap={!disabled ? { scale: 0.98 } : {}}
          onClick={onContinue}
          disabled={disabled}
          className={`flex items-center justify-center gap-2 px-10 py-3.5 rounded-xl text-sm font-bold transition-all min-w-[180px] ${
            disabled
              ? "bg-gray-100 text-gray-400 cursor-not-allowed"
              : "bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg shadow-blue-500/30 hover:shadow-blue-500/50"
          }`}
        >
          Continue
          {!disabled && <ArrowRight className="w-4 h-4" />}
        </motion.button>
      </div>
    </motion.div>
  );
};
