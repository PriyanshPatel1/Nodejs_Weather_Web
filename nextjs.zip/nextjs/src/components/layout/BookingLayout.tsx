"use client";

import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { BookingSummaryType, StepStatus } from "../../types/booking";
import { TripSidebar } from "./TripSidebar";
import { BottomActionBar } from "./BottomActionBar";
import { StepProgress } from "./StepProgress";
import { ArrowLeft } from "lucide-react";

interface BookingLayoutProps {
  currentStep: StepStatus;
  summary: BookingSummaryType;
  title: string;
  subtitle: string;
  onContinue: () => void;
  onBack: () => void;
  isContinueDisabled?: boolean;
  onEditStep?: (step: StepStatus) => void;
  children: React.ReactNode;
}

export const BookingLayout = ({
  currentStep,
  summary,
  title,
  subtitle,
  onContinue,
  onBack,
  isContinueDisabled,
  onEditStep,
  children,
}: BookingLayoutProps) => {
  const handle3DToggle = () => {
    alert("3D View will be available shortly!");
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] font-sans text-gray-900 overflow-hidden">
      <TripSidebar summary={summary} />

      <main className="ml-[300px] h-screen flex flex-col">
        {/* Top Header */}
        <header className="px-8 pt-8 pb-4 flex items-center justify-between flex-shrink-0 z-10 relative">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-[#0A1931] mb-1">
              {title}
            </h1>
            <p className="text-sm text-gray-500">{subtitle}</p>
          </div>

          <div className="absolute left-1/2 -translate-x-1/2 top-4 w-full max-w-xl">
             <StepProgress currentStep={currentStep} />
          </div>

          <div className="flex items-center gap-4">
            {/* 2D/3D Toggle (Only visible on seat selection usually, but kept in layout for match) */}
            {currentStep === "select-seat" && (
              <div className="flex bg-white rounded-lg border border-gray-200 p-1 shadow-sm">
                <button className="px-4 py-1.5 rounded-md bg-blue-600 text-white text-xs font-semibold shadow-sm">
                  2D View
                </button>
                <button onClick={handle3DToggle} className="px-4 py-1.5 rounded-md text-gray-500 text-xs font-semibold hover:bg-gray-50 transition-colors">
                  3D View
                </button>
              </div>
            )}

            {currentStep !== "plan" && currentStep !== "confirmation" && (
              <button onClick={onBack} className="flex items-center gap-2 text-xs font-semibold text-gray-700 bg-white border border-gray-200 px-4 py-2.5 rounded-lg shadow-sm hover:bg-gray-50 transition-colors">
                <ArrowLeft className="w-4 h-4" />
                Back
              </button>
            )}
          </div>
        </header>

        {/* Main Content Area */}
        <div className="flex-1 relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentStep}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.35, ease: "easeInOut" }}
              className="absolute inset-0 overflow-y-auto pb-[90px]"
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      <BottomActionBar
        currentStep={currentStep}
        summary={summary}
        onContinue={onContinue}
        disabled={isContinueDisabled}
      />
    </div>
  );
};
