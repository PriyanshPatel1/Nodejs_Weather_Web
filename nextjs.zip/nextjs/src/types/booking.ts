export type StepStatus = "plan" | "select-seat" | "payment" | "confirmation";

export interface Flight {
  id: string;
  flightNumber: string;
  aircraft: string;
  departureCity: string;
  arrivalCity: string;
  departureCode: string;
  arrivalCode: string;
  departureTime: string;
  arrivalTime: string;
  date: string;
  duration: string;
  baseFare: number;
  bestValue?: boolean;
}

export interface Passenger {
  name: string;
  type: string;
  count: number;
}

export type CabinClass = "Business" | "Premium Economy" | "Economy";
export type SeatStatus = "available" | "booked" | "selected";

export const CABIN_CLASS_PRICE_ADDON: Record<CabinClass, number> = {
  Business: 150,
  "Premium Economy": 50,
  Economy: 0,
};

export interface Seat {
  id: string; // e.g., "18A"
  row: number;
  column: string;
  cabinClass: CabinClass;
  status: SeatStatus;
  isExtraLegroom: boolean;
  price: number;
  features: string[];
}

export interface BookingSummaryType {
  flight: Flight | null;
  passenger: Passenger;
  selectedSeats: Seat[];
  selectedCabinClass: CabinClass;
  taxesAndFees: number;
  discount?: number;
}
